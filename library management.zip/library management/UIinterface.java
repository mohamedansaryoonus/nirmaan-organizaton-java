package day22;

import java.util.ArrayList;

import java.util.Scanner;

public class UIinterface {

	public static void main(String[] args) {
		ArrayList<Book> books = new ArrayList<Book>();
		Scanner sc = new Scanner(System.in);
		
		service service =new service();
		Book book =new Book();
		System.out.println("Enter the key \n 1 for post book \n 2 for get the book\n 3 for get the bookid \n 4 for put the bookid \n 5 for delete the book");
		int key=sc.nextInt();
		while(true)
			
		switch(key) {
		case 1:
			Book b=service.addBook();
			books.add(b);
			
		case 2:
			service s=new service();
			
		case 3:
			System.out.println("Enter the book id:");
			int id=sc.nextInt();
			System.out.println(service.getBook(books, id));
			
		case 4:
			service.putBook(books);
			
		case 5:
			service.DeleteBook(books);
		}
		

		
			
		
	}

}
